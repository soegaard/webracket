This folder is published on Github Pages as the web-site for WebRacket.
